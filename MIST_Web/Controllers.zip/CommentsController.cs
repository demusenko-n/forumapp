﻿using EfTest.Context;
using Infrastructure.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using Infrastructure;

namespace WebServer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommentsController : ControllerBase
    {
        private readonly ForumDbContext _context;
        public CommentsController(ForumDbContext context)
        {   
            _context = context;
        }
        [HttpGet]
        public async Task<ActionResult<List<Comment>>> Get()
        {
            return await _context.Comments.ToListAsync();
        }

        [HttpPost("add")]
        public async Task<TransferObj<Comment?>> Add(Comment comment)
        {
            try
            {
                comment.Date = DateTime.UtcNow;

                var resultsCheck = new List<ValidationResult>();
                if (!Validator.TryValidateObject(comment, new ValidationContext(comment), resultsCheck, true))
                    return new TransferObj<Comment?>(null, string.Join("\n", resultsCheck.Select(r => r.ErrorMessage)));

                _context.Comments.Add(comment);
                await _context.SaveChangesAsync();

                return new TransferObj<Comment?>(comment);
            }
            catch (Exception ex)
            {
                return new TransferObj<Comment?>(null, ex.Message);
            }
        }
    }

}
